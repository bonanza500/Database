-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 20, 2024 at 05:53 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `project aol`
--

-- --------------------------------------------------------

--
-- Table structure for table `employee`
--

CREATE TABLE `employee` (
  `id` varchar(50) NOT NULL,
  `no` int(11) DEFAULT NULL,
  `nama` varchar(100) DEFAULT NULL,
  `technology` varchar(50) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `no_hp` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `employee`
--

INSERT INTO `employee` (`id`, `no`, `nama`, `technology`, `email`, `no_hp`) VALUES
('E001', 1, 'Dony AP', 'PM', 'dony.ap@gmail.com', '85695140357'),
('E002', 2, 'Ismail Taufik', 'SEC', 'ismail.taufik@gmail.com', '86748930994'),
('E003', 3, 'Dion Wirya', 'SEC', 'dion.wirya@gmail.com', '809924902494'),
('E004', 4, 'Bernard Suwandi', 'PM', 'bernard.suwandi@gmail.com', '86423446533'),
('E005', 5, 'Muhammad Ahsan', 'SEC', 'muhammad.ahsan@gmail.com', '86263463322'),
('E006', 6, 'Ahmad Wildani', 'SEC', 'ahmad.wildani@gmail.com', '88076363673'),
('E007', 7, 'Charlie Septian', 'PM', 'charlie.septian@gmail.com', '84374343464'),
('E008', 8, 'Dani Adinanta', 'SEC', 'dani.adinanta@gmail.com', '87373534098'),
('E009', 9, 'Ranjit Pramono', 'SEC', 'ranjit.pramono@gmail.com', '86434662627'),
('E010', 10, 'Cornelius Arhan', 'PM', 'cornelius.arhan@gmail.com', '86636342936'),
('E011', 11, 'Yolanda Dian', 'SEC', 'yolanda.dian@gmail.com', '86316436417'),
('E012', 12, 'Galih Rasyid', 'SEC', 'galih.rasyid@gmail.com', '83488671300'),
('E013', 13, 'Cornelius Arhan', 'PM', 'cornelius.arhan@gmail.com', '86636342936'),
('E014', 14, 'Nindi Permatasari', 'SEC', 'nindi.permatasari@gmail.com', '86562626344'),
('E015', 15, 'Kevin Sihombing', 'SEC', 'kevin.sihombing@gmail.com', '87535353637'),
('E016', 16, 'Stevan Damar', 'PM', 'stevan.damar@gmail.com', '81636277364'),
('E017', 17, 'Faiz Fadli', 'SEC', 'faiz.fadli@gmail.com', '83273737837'),
('E018', 18, 'Radhitya Hambali', 'SEC', 'radhitya.hambali@gmail.com', '86893298848'),
('E019', 19, 'Bonar Yuwandaru', 'PM', 'bonar.yuwandru@gmail.com', '89844786578'),
('E020', 20, 'Warsito Ferdinand', 'F5', 'warsito.ferdinand@gmail.com', '88673324490'),
('E021', 21, 'Emery Chandra', 'F5', 'emery.chandra@gmail.com', '84788659055'),
('E022', 22, 'Vanessa Halim', 'F5', 'vanessa.halim@gmail.com', '87452190087'),
('E023', 23, 'Ardi Syaiful', 'F5', 'ardi.syaiful@gmail.com', '86745764578'),
('E024', 24, 'Dony AP', 'PM', 'dony.ap@gmail.com', '85695140357'),
('E025', 25, 'Dwi Setyo', 'CORE', 'dwi.setyo@gmail.com', '80894463284'),
('E026', 26, 'Irwandi Togu', 'CORE', 'irwandi.togu@gmail.com', '89433793209'),
('E027', 27, 'Abraham James', 'ACI', 'abraham.james@gmail.com', '85343695432'),
('E028', 28, 'Yusril Agustine', 'ACI', 'yusril.agustine@gmail.com', '83230439493'),
('E029', 29, 'Aldo Bramasta', 'ACI', 'aldo.bramasta@gmail.com', '87990435861'),
('E030', 30, 'Irwandi Togu', 'OOB', 'irwandi.togu@gmail.com', '86483640927'),
('E031', 31, 'Samsul Arfin', 'OOB', 'samsul.arfin@gmail.com', '89646300832'),
('E032', 32, 'Yusril Agustine', 'OOB', 'yusril.agustine@gmail.com', '89034722893'),
('E033', 33, 'Risa Pratikno', 'PM', 'risa.pratikno@gmail.com', '86347901883'),
('E034', 34, 'Adit Prasanto', 'NI', 'adit.prasanto@gmail.com', '82839104881'),
('E035', 35, 'Aldo Bramasta', 'NI', 'aldo.bramasta@gmail.com', '87990435861'),
('E036', 36, 'Erica Lim', 'PM', 'erica.lim@gmail.com', '87990435861'),
('E037', 37, 'Kamala Trihapsari', 'NI', 'kamala.trihapsari@gmail.com', '86135130193'),
('E038', 38, 'Dhea Nurbaya', 'NI', 'dhea.nurbaya@gmail.com', '86141267180'),
('E039', 39, 'Erica Lim', 'PM', 'erica.lim@gmail.com', '87990435861'),
('E040', 40, 'Wayan Handra', 'CORE, WLC', 'wayan.handra@gmail.com', '84124164092'),
('E041', 41, 'Dhea Nurbaya', 'CORE, WLC', 'dhea.nurbaya@gmail.com', '86141267180'),
('E042', 42, 'Abraham James', 'CORE, WLC', 'abraham.james@gmail.com', '85343695432'),
('E043', 43, 'Abdi Aldiansyah', 'ISE', 'abdi.aldiansyah@gmail.com', '86452372921'),
('E044', 44, 'Charlie Septian', 'PM', 'charlie.septian@gmail.com', '84374343464'),
('E045', 45, 'Lukman Muchtar', 'NI', 'lukman.muchtar@gmail.com', '81327233337'),
('E046', 46, 'Ahmad Suryadi', 'NI', 'ahmad.suryadi@gmail.com', '86900124635'),
('E047', 47, 'Charlie Septian', 'PM', 'charlie.septian@gmail.com', '84374343464'),
('E048', 48, 'Adi Purba', 'CISCO', 'adi.purba@gmail.com', '86612374832'),
('E049', 49, 'Lukito Sutedjo', 'CISCO', 'lukito.sutedjo@gmail.com', '80722837741'),
('E050', 50, 'Warsito Ferdinand', 'F5', 'warsito.ferdinand@gmail.com', '88673324490'),
('E051', 51, 'Emery Chandra', 'F5', 'emery.chandra@gmail.com', '84788659055'),
('E052', 52, 'Vanessa Halim', 'F5', 'vanessa.halim@gmail.com', '87452190087'),
('E053', 53, 'Ardi Syaiful', 'F5', 'ardi.syaiful@gmail.com', '86745764578'),
('E054', 54, 'Bonar Yuwandaru', 'PM', 'bonar.yuwandaru@gmail.com', '89844786578'),
('E055', 55, 'Rochmatul Hidayatulah', 'NI', 'rochmatul.hidayatulah@gmail.com', '81997524170'),
('E056', 56, 'Adi Purba', 'NI', 'adi.purba@gmail.com', '86612374832'),
('E057', 57, 'Ahmad Wildani', 'NI', 'ahmad.wildani@gmail.com', '88076363673'),
('E058', 58, 'Charlie Septian', 'PM', 'charlie.septian@gmail.com', '84374343464'),
('E059', 59, 'Tommy Suryono', 'VOICE', 'tommy.suryono@gmail.com', '82248701375'),
('E060', 60, 'Stevan Damar', 'PM', 'stevan.damar@gmail.com', '81636277364'),
('E061', 61, 'Ahmad Dicky', 'F5', 'ahmad.dicky@gmail.com', '86802843818'),
('E062', 62, 'Kurniawan Danandaru', 'F5', 'kurniawan.danandaru@gmail.com', '84141829125'),
('E063', 63, 'Cornelius Arhan', 'PM', 'cornelius.arhan@gmail.com', '86636342936'),
('E064', 64, 'Galang Hutapea', 'NI', 'galang.hutapea@gmail.com', '83246009817'),
('E065', 65, 'Benny Hanafie', 'NI', 'benny.hanafie@gmail.com', '87715305562'),
('E066', 66, 'Risa Pratikno', 'PM', 'risa.pratikno@gmail.com', '86826310086'),
('E067', 67, 'Galang Hutapea', 'NI', 'galang.hutapea@gmail.com', '83246009817'),
('E068', 68, 'Benny Hanafie', 'NI', 'benny.hanafie@gmail.com', '87715305562');

-- --------------------------------------------------------

--
-- Table structure for table `project`
--

CREATE TABLE `project` (
  `id` varchar(50) NOT NULL,
  `project_progress_summary` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `project`
--

INSERT INTO `project` (`id`, `project_progress_summary`) VALUES
('P001', 'Project DCNM Phase 1 in progress'),
('P002', 'Project Arbor ImproOCement_Phase 4 in progress'),
('P003', 'Project Firewall Gi Upgrade OS 2024 in progress'),
('P004', 'Project Gi Firewall Architecture Re-engineering in progress'),
('P005', 'Project ISE 2024 – Implementation SASE in progress'),
('P006', 'Project Upgrade ISE AAA in progress'),
('P007', 'Project F5 Load Balancer (Standby On Call)'),
('P008', 'Project DCNM Ph1 and 2 (Standby On call)'),
('P009', 'Project Network EOSL 2023_Minor DC (Standby On call)'),
('P010', 'Project AP Modernization Phase 2 (Standby On call)'),
('P011', 'Project LAN Modernization 2024 (Standby On call)'),
('P012', 'Project EDD_NOCFi OCas Modernization (Standby On call)'),
('P013', 'Project IGW Delta Swap and Incremental(Standby On call)'),
('P014', 'Project EOSL RSP Linecard Refreshment Cisco 2023 (Standby On call)'),
('P015', 'Project Contact Center Modernization in progress'),
('P016', 'Project F5 TMOS Software Upgrade CP1 2024 in progress'),
('P017', 'Project EBR CP1 Phase 1, 2 in progress'),
('P018', 'Project CI, Gi-Switch in progress');

-- --------------------------------------------------------

--
-- Table structure for table `schedule`
--

CREATE TABLE `schedule` (
  `id` varchar(50) NOT NULL,
  `date` date DEFAULT NULL,
  `status` varchar(20) DEFAULT NULL,
  `employee_no` varchar(50) DEFAULT NULL,
  `project_id` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `schedule`
--

INSERT INTO `schedule` (`id`, `date`, `status`, `employee_no`, `project_id`) VALUES
('S001', '2024-12-23', 'OC', 'E001', 'P001'),
('S002', '2024-12-24', 'OC', 'E001', 'P001'),
('S003', '2024-12-25', 'OC', 'E001', 'P001'),
('S004', '2024-12-23', 'OC', 'E002', 'P001'),
('S005', '2024-12-24', 'OC', 'E002', 'P001'),
('S006', '2024-12-25', 'OC', 'E002', 'P001'),
('S007', '2024-12-23', NULL, 'E003', 'P001'),
('S008', '2024-12-24', NULL, 'E003', 'P001'),
('S009', '2024-12-25', NULL, 'E003', 'P001'),
('S010', '2024-12-23', 'OC', 'E004', 'P002'),
('S011', '2024-12-24', 'OC', 'E004', 'P002'),
('S012', '2024-12-25', 'OC', 'E004', 'P002'),
('S013', '2024-12-23', 'OC', 'E005', 'P002'),
('S014', '2024-12-24', 'OC', 'E005', 'P002'),
('S015', '2024-12-25', 'OC', 'E005', 'P002'),
('S016', '2024-12-23', NULL, 'E005', 'P002'),
('S017', '2024-12-24', NULL, 'E005', 'P002'),
('S018', '2024-12-25', NULL, 'E005', 'P002'),
('S019', '2024-12-23', 'OC', 'E006', 'P003'),
('S020', '2024-12-24', 'OC', 'E006', 'P003'),
('S021', '2024-12-25', 'OC', 'E006', 'P003'),
('S022', '2024-12-23', 'OC', 'E007', 'P003'),
('S023', '2024-12-24', 'OC', 'E007', 'P003'),
('S024', '2024-12-25', 'OC', 'E007', 'P003'),
('S025', '2024-12-23', NULL, 'E008', 'P003'),
('S026', '2024-12-24', NULL, 'E008', 'P003'),
('S027', '2024-12-25', NULL, 'E008', 'P003'),
('S028', '2024-12-23', 'OC', 'E009', 'P004'),
('S029', '2024-12-24', 'OC', 'E009', 'P004'),
('S030', '2024-12-25', 'OC', 'E009', 'P004'),
('S031', '2024-12-23', 'OC', 'E010', 'P004'),
('S032', '2024-12-24', 'OC', 'E010', 'P004'),
('S033', '2024-12-25', 'OC', 'E010', 'P004'),
('S034', '2024-12-23', NULL, 'E011', 'P004'),
('S035', '2024-12-24', NULL, 'E011', 'P004'),
('S036', '2024-12-25', NULL, 'E011', 'P004'),
('S037', '2024-12-23', 'OC', 'E012', 'P005'),
('S038', '2024-12-24', 'OC', 'E012', 'P005'),
('S039', '2024-12-25', 'OC', 'E012', 'P005'),
('S040', '2024-12-23', 'OC', 'E013', 'P005'),
('S041', '2024-12-24', 'OC', 'E013', 'P005'),
('S042', '2024-12-25', 'OC', 'E013', 'P005'),
('S043', '2024-12-23', NULL, 'E014', 'P005'),
('S044', '2024-12-24', NULL, 'E014', 'P005'),
('S045', '2024-12-25', NULL, 'E014', 'P005'),
('S046', '2024-12-23', 'OC', 'E015', 'P006'),
('S047', '2024-12-24', 'OC', 'E015', 'P006'),
('S048', '2024-12-25', 'OC', 'E015', 'P006'),
('S049', '2024-12-23', 'OC', 'E016', 'P006'),
('S050', '2024-12-24', 'OC', 'E016', 'P006'),
('S051', '2024-12-25', 'OC', 'E016', 'P006'),
('S052', '2024-12-23', NULL, 'E017', 'P006'),
('S053', '2024-12-24', NULL, 'E017', 'P006'),
('S054', '2024-12-25', NULL, 'E017', 'P006'),
('S055', '2024-12-23', 'OC', 'E018', 'P007'),
('S056', '2024-12-24', 'OC', 'E018', 'P007'),
('S057', '2024-12-25', 'OC', 'E018', 'P007'),
('S058', '2024-12-23', NULL, 'E019', 'P007'),
('S059', '2024-12-24', NULL, 'E019', 'P007'),
('S060', '2024-12-25', NULL, 'E019', 'P007'),
('S061', '2024-12-23', NULL, 'E020', 'P007'),
('S062', '2024-12-24', NULL, 'E020', 'P007'),
('S063', '2024-12-25', NULL, 'E020', 'P007'),
('S064', '2024-12-23', 'OC', 'E021', 'P007'),
('S065', '2024-12-24', 'OC', 'E021', 'P007'),
('S066', '2024-12-25', 'OC', 'E021', 'P007'),
('S067', '2024-12-23', 'OC', 'E022', 'P008'),
('S068', '2024-12-24', 'OC', 'E022', 'P008'),
('S069', '2024-12-25', 'OC', 'E022', 'P008'),
('S070', '2024-12-23', 'OC', 'E023', 'P008'),
('S071', '2024-12-24', 'OC', 'E023', 'P008'),
('S072', '2024-12-25', 'OC', 'E023', 'P008'),
('S073', '2024-12-23', NULL, 'E024', 'P008'),
('S074', '2024-12-24', NULL, 'E024', 'P008'),
('S075', '2024-12-25', NULL, 'E024', 'P008'),
('S076', '2024-12-23', NULL, 'E025', 'P008'),
('S077', '2024-12-24', NULL, 'E025', 'P008'),
('S078', '2024-12-25', 'OC', 'E025', 'P008'),
('S079', '2024-12-23', 'OC', 'E026', 'P008'),
('S080', '2024-12-24', 'OC', 'E026', 'P008'),
('S081', '2024-12-25', NULL, 'E026', 'P008'),
('S082', '2024-12-23', NULL, 'E027', 'P008'),
('S083', '2024-12-24', NULL, 'E027', 'P008'),
('S084', '2024-12-25', NULL, 'E027', 'P008'),
('S085', '2024-12-23', 'OC', 'E028', 'P008'),
('S086', '2024-12-24', 'OC', 'E028', 'P008'),
('S087', '2024-12-25', 'OC', 'E028', 'P008'),
('S088', '2024-12-23', NULL, 'E029', 'P008'),
('S089', '2024-12-24', NULL, 'E029', 'P008'),
('S090', '2024-12-25', NULL, 'E029', 'P008'),
('S091', '2024-12-23', NULL, 'E030', 'P008'),
('S092', '2024-12-24', NULL, 'E030', 'P008'),
('S093', '2024-12-25', NULL, 'E030', 'P008'),
('S094', '2024-12-23', 'OC', 'E031', 'P009'),
('S095', '2024-12-24', 'OC', 'E031', 'P009'),
('S096', '2024-12-25', 'OC', 'E031', 'P009'),
('S097', '2024-12-23', 'OC', 'E032', 'P009'),
('S098', '2024-12-24', 'OC', 'E032', 'P009'),
('S099', '2024-12-25', 'OC', 'E032', 'P009'),
('S100', '2024-12-23', NULL, 'E033', 'P009'),
('S101', '2024-12-24', NULL, 'E033', 'P009'),
('S102', '2024-12-25', NULL, 'E033', 'P009'),
('S103', '2024-12-23', 'OC', 'E034', 'P010'),
('S104', '2024-12-24', 'OC', 'E034', 'P010'),
('S105', '2024-12-25', 'OC', 'E034', 'P010'),
('S106', '2024-12-23', 'OC', 'E035', 'P010'),
('S107', '2024-12-24', 'OC', 'E035', 'P010'),
('S108', '2024-12-25', 'OC', 'E035', 'P010'),
('S109', '2024-12-23', NULL, 'E036', 'P010'),
('S110', '2024-12-24', NULL, 'E036', 'P010'),
('S111', '2024-12-25', NULL, 'E036', 'P010'),
('S112', '2024-12-23', 'OC', 'E037', 'P011'),
('S113', '2024-12-24', 'OC', 'E037', 'P011'),
('S114', '2024-12-25', 'OC', 'E037', 'P011'),
('S115', '2024-12-23', 'OC', 'E038', 'P011'),
('S116', '2024-12-24', 'OC', 'E038', 'P011'),
('S117', '2024-12-25', NULL, 'E038', 'P011'),
('S118', '2024-12-23', NULL, 'E039', 'P011'),
('S119', '2024-12-24', NULL, 'E039', 'P011'),
('S120', '2024-12-25', 'OC', 'E039', 'P011'),
('S121', '2024-12-23', NULL, 'E040', 'P011'),
('S122', '2024-12-24', NULL, 'E040', 'P011'),
('S123', '2024-12-25', NULL, 'E040', 'P011'),
('S124', '2024-12-23', 'OC', 'E041', 'P011'),
('S125', '2024-12-24', 'OC', 'E041', 'P011'),
('S126', '2024-12-25', 'OC', 'E041', 'P011'),
('S127', '2024-12-23', 'OC', 'E042', 'P012'),
('S128', '2024-12-24', 'OC', 'E042', 'P012'),
('S129', '2024-12-25', 'OC', 'E042', 'P012'),
('S130', '2024-12-23', NULL, 'E043', 'P012'),
('S131', '2024-12-24', NULL, 'E043', 'P012'),
('S132', '2024-12-25', NULL, 'E043', 'P012'),
('S133', '2024-12-23', 'OC', 'E044', 'P012'),
('S134', '2024-12-24', 'OC', 'E044', 'P012'),
('S135', '2024-12-25', 'OC', 'E044', 'P012'),
('S136', '2024-12-23', 'OC', 'E045', 'P013'),
('S137', '2024-12-24', 'OC', 'E045', 'P013'),
('S138', '2024-12-25', 'OC', 'E045', 'P013'),
('S139', '2024-12-23', NULL, 'E046', 'P013'),
('S140', '2024-12-24', NULL, 'E046', 'P013'),
('S141', '2024-12-25', NULL, 'E046', 'P013'),
('S142', '2024-12-23', 'OC', 'E047', 'P013'),
('S143', '2024-12-24', 'OC', 'E047', 'P013'),
('S144', '2024-12-25', 'OC', 'E047', 'P013'),
('S145', '2024-12-23', NULL, 'E048', 'P013'),
('S146', '2024-12-24', NULL, 'E048', 'P013'),
('S147', '2024-12-25', NULL, 'E048', 'P013'),
('S148', '2024-12-23', 'OC', 'E049', 'P013'),
('S149', '2024-12-24', 'OC', 'E049', 'P013'),
('S150', '2024-12-25', 'OC', 'E049', 'P013'),
('S151', '2024-12-23', NULL, 'E050', 'P013'),
('S152', '2024-12-24', NULL, 'E050', 'P013'),
('S153', '2024-12-25', NULL, 'E050', 'P013'),
('S154', '2024-12-23', NULL, 'E051', 'P013'),
('S155', '2024-12-24', NULL, 'E051', 'P013'),
('S156', '2024-12-25', NULL, 'E051', 'P013'),
('S157', '2024-12-23', 'OC', 'E052', 'P014'),
('S158', '2024-12-24', 'OC', 'E052', 'P014'),
('S159', '2024-12-25', 'OC', 'E052', 'P014'),
('S160', '2024-12-23', NULL, 'E053', 'P014'),
('S161', '2024-12-24', NULL, 'E053', 'P014'),
('S162', '2024-12-25', NULL, 'E053', 'P014'),
('S163', '2024-12-23', 'OC', 'E054', 'P014'),
('S164', '2024-12-24', 'OC', 'E054', 'P014'),
('S165', '2024-12-25', 'OC', 'E054', 'P014'),
('S166', '2024-12-23', NULL, 'E055', 'P014'),
('S167', '2024-12-24', NULL, 'E055', 'P014'),
('S168', '2024-12-25', NULL, 'E055', 'P014'),
('S169', '2024-12-23', 'OC', 'E056', 'P015'),
('S170', '2024-12-24', 'OC', 'E056', 'P015'),
('S171', '2024-12-25', 'OC', 'E056', 'P015'),
('S172', '2024-12-23', 'OC', 'E057', 'P015'),
('S173', '2024-12-24', 'OC', 'E057', 'P015'),
('S174', '2024-12-25', 'OC', 'E057', 'P015'),
('S175', '2024-12-23', 'OC', 'E058', 'P016'),
('S176', '2024-12-24', 'OC', 'E058', 'P016'),
('S177', '2024-12-25', 'OC', 'E058', 'P016'),
('S178', '2024-12-23', 'OC', 'E059', 'P016'),
('S179', '2024-12-24', 'OC', 'E059', 'P016'),
('S180', '2024-12-25', 'OC', 'E059', 'P016'),
('S181', '2024-12-23', NULL, 'E060', 'P016'),
('S182', '2024-12-24', NULL, 'E060', 'P016'),
('S183', '2024-12-25', NULL, 'E060', 'P016'),
('S184', '2024-12-23', 'OC', 'E061', 'P017'),
('S185', '2024-12-24', 'OC', 'E061', 'P017'),
('S186', '2024-12-25', 'OC', 'E061', 'P017'),
('S187', '2024-12-23', 'OC', 'E062', 'P017'),
('S188', '2024-12-24', 'OC', 'E062', 'P017'),
('S189', '2024-12-25', 'OC', 'E062', 'P017'),
('S190', '2024-12-23', NULL, 'E063', 'P017'),
('S191', '2024-12-24', NULL, 'E063', 'P017'),
('S192', '2024-12-25', NULL, 'E063', 'P017'),
('S193', '2024-12-23', 'OC', 'E064', 'P018'),
('S194', '2024-12-24', 'OC', 'E064', 'P018'),
('S195', '2024-12-25', 'OC', 'E064', 'P018'),
('S196', '2024-12-23', 'OC', 'E065', 'P018'),
('S197', '2024-12-24', 'OC', 'E065', 'P018'),
('S198', '2024-12-25', 'OC', 'E065', 'P018'),
('S199', '2024-12-23', NULL, 'E066', 'P018'),
('S200', '2024-12-24', NULL, 'E066', 'P018'),
('S201', '2024-12-25', NULL, 'E066', 'P018');

-- --------------------------------------------------------

--
-- Table structure for table `tech`
--

CREATE TABLE `tech` (
  `id` varchar(20) NOT NULL,
  `technology` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tech`
--

INSERT INTO `tech` (`id`, `technology`) VALUES
('T001', 'PM'),
('T002', 'SEC'),
('T003', 'SEC');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `employee`
--
ALTER TABLE `employee`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `project`
--
ALTER TABLE `project`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `schedule`
--
ALTER TABLE `schedule`
  ADD PRIMARY KEY (`id`),
  ADD KEY `employee_no` (`employee_no`),
  ADD KEY `project_id` (`project_id`);

--
-- Indexes for table `tech`
--
ALTER TABLE `tech`
  ADD PRIMARY KEY (`id`);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `schedule`
--
ALTER TABLE `schedule`
  ADD CONSTRAINT `schedule_ibfk_1` FOREIGN KEY (`employee_no`) REFERENCES `employee` (`id`),
  ADD CONSTRAINT `schedule_ibfk_2` FOREIGN KEY (`project_id`) REFERENCES `project` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
